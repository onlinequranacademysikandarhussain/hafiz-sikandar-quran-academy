HAFIZ SIKANDAR ONLINE QURAN ACADEMY — WEBSITE FILES

Quick preview:
1. Open index.html in a browser (Chrome works).
2. The site is a single self-contained HTML file and includes the uploaded portrait.
3. WhatsApp contact is set to 03118132377.
4. Admission form prepares a WhatsApp message; it does not store submissions on a server.

Free publishing (GitHub Pages):
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. hafiz-sikandar-quran-academy.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the Pages URL to appear. Share that URL on Facebook.
Note: GitHub's interface can change; a custom domain is optional and usually costs money.

Before publishing, please review all wording and confirm that the course list and contact number are correct.
